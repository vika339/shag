<?php 
$a= $_POST['day'];

echo $a;
$m2 = array (
    'monday' => array(3, 10, 17, 24, 31),
    'tuesday' => array(4, 11, 18, 25),
    'wednesday' =>array(5, 12, 19, 26)
  );
echo '<br>';
  print_r($m2[$a]);

 ?>