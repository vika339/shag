<?php
$m = array (3,4,'Hello', 67);
  for ($i=0; $i<count($m); $i++){
    echo ($m[$i].' ');
}
?>