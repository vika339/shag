<?php
$m2 = array (
    'monday' => array(3, 10, 17, 24, 31),
    'two' => array(4, 11, 18, 25),
    'yy' =>array(5, 12, 19, 26)
  );
  foreach($m2 as $key=>$value) {
  echo ($key.' --- ');
 
}
?>